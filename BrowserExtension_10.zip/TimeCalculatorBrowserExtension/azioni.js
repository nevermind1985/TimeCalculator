$(document).ready(function() {
	setTimeout(checkTimeLink, 5000);
});

function checkTimeLink() {	
	$('.ui-grid-cell-contents.ng-binding.ng-scope').each(function(i, obj) {
															var divObject = obj.innerHTML;
															if(divObject.indexOf('E') >= 0) {
																var newText = "<a href='https://nevermind1985.github.io/TimeCalculator/?"+divObject+"' target='_blank' style='color:green;'>"+divObject+"</a>";
																obj.innerHTML = newText;
															}
														});
}